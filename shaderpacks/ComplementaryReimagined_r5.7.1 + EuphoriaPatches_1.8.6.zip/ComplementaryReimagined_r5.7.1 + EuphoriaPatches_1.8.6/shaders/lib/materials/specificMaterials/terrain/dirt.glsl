smoothnessG = color.r * 0.1 + 0.1;
